# Workshop II · Preparatory homework (3–8 November)

The Enron mail case. Every name starts with `ws2_`, for Workshop II.

The homework says when you need which file (step 8 and Part C).

## Langflow: upload all four in step 8

| File | Langflow flow | What it does |
|---|---|---|
| `langflow/ws2_triage_enron.json` | Triage (Enron) | sorts one mail: MailEx events, action (calendar, reply, forward, archive), deadline; checks its own answer (`checks_ok`, `problems`) |
| `langflow/ws2_draft_reply_enron.json` | Draft Reply (Enron) | drafts Vince Kaminski's reply from his earlier mails, as of the mail's date; never from a confidential mail; checks its own draft (`checks_ok`, `problems`) |
| `langflow/ws2_ask_mailbox_enron.json` | Ask Mailbox (Enron) | answers questions about the mailbox, with sources |
| `langflow/ws2_judge_draft_enron.json` | Judge Draft (Enron) | grades a draft against the reply really sent, 1 to 5 (right from 4); checks its grade; for the test bench of 16 November |

## n8n

| File | n8n workflow | What it does |
|---|---|---|
| `n8n/ws2_0_embed_mails.json` | WS2.0 - Embed Mails | embeds every mail of your mailbox into `n8n_workshop_mail.chunks`, so the search finds it |

## Setting up (short version)

The homework walks you through all of this step by step. The short version, to look things up later:

- Your pod runs in mode `abp`, and your test account is connected and holds Kaminski's mails (`./kingo mail`,
  `./kingo mail seed`).
- In Langflow, your OpenRouter key is a global variable named `OPEN_ROUTER_API_KEY`, with the key Yanbo gave you.

1. **Langflow:** make a project "WS2 - Mail Assistant (Enron)" and upload the four files from `langflow/`. In Settings →
   Langflow API Keys, **Add New** (description `n8n`, no expiration date), then copy the key.
2. **n8n, credentials:** create four, with exactly these names:
   - `Mail (n8n_workshop_mail_n8n)`, type Postgres: host `postgres`, database `classroom`, user
     `n8n_workshop_mail_n8n`, password `kingo2026`, port `5432`, SSL `disable`.
   - `OpenRouter (embeddings)`, type Header Auth: name `Authorization`, value the word `Bearer`, one space, then your
     OpenRouter key.
   - `Langflow (Run API)`, type Header Auth: name `x-api-key`, value your Langflow API key.
   - `OpenRouter (chat)`, type OpenRouter: your OpenRouter key (the guard's model).
3. **n8n, WS2.0:** *Import from File* `n8n/ws2_0_embed_mails.json`; where a node asks for a credential, pick the one of
   the same name. Publish it: it embeds your mailbox, in our test in about 12 minutes.
